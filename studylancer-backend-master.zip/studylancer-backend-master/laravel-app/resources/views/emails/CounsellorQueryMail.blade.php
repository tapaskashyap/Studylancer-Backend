<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Counsellor Query Mail</title>
</head>
<body>
	<h3>Name : {{ $name }}</h3>
	<h3>Email : {{ $email }}</h3>
	<h3>Phone : {{ $phone }}</h3>
	<h3>Query :</h3>
	<p>{{ $text }}</p>
</body>
</html>