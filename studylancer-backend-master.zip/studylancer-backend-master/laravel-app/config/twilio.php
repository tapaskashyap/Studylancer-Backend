<?php

return [

    'account_sid' => env('TWILIO_ACCOUNT_SID', 'null'),

    'auth_token' => env('TWILIO_AUTH_TOKEN', 'null'),

    'verification_sid' => env('TWILIO_VERIFICATION_SID', 'null'),
];
